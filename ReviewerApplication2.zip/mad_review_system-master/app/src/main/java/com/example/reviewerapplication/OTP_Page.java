package com.example.reviewerapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class OTP_Page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_page);
    }
}